#!/bin/bash

source .env/bin/activate

while  true
	do
	python3 -u bot07.py >> lrconsole.log 2>&1
	sleep 60
done
