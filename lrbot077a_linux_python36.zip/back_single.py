import sys
import os
import platform
import shutil
import time
import csv

import subprocess

from lrhelper import LRBotVersion


# ==================================================

def bs_loadcsvfile(infile):
    csvFile = open(infile)
    csvReader = csv.reader(csvFile)
    csvlines = list(csvReader)
    csvFile.close()
    return csvlines

def bs_getidx(idx, csvlines):
    titleline = idxline = ''
    # first, get number of field 'idx'
    titleline = csvlines[0]
    idxidx = -1
    for i in range(len(titleline)):
        fieldname = titleline[i]
        if fieldname == 'idx':
            idxidx = i
            break
    # second, get parameter line with <idx>
    ht_params = {}
    if idxidx > -1:
        for oneline in csvlines:
            if str(oneline[idxidx]) == str(idx):
                idxline = oneline
                ht_params = bs_cnv2hash(titleline, idxline)
                break
    if len(ht_params) > 0:
        print("Parameter Set {} found.\n".format(idx))
    return ht_params

def bs_cnv2hash(titleline, idxline):
    ht_param = {}
    for i in range(len(titleline)):
        mykey = titleline[i]
        myval = idxline[i]
        ht_param[mykey] = myval
    return ht_param

def bs_load_inifile(filename):
    iniFile = open(filename)
    inilines = iniFile.readlines()
    iniFile.close()
    print("Infile '{}' contains {} lines.\n".format(filename, len(inilines)-1))
    return inilines

def bs_write_inifile(inilines, ht_params, outfile):
    iniline_out = []
    print("Checking old ini file")
    for oneline in inilines:
        oneline = oneline.strip()
        if oneline.startswith('strategy = '):
            parts = oneline.split(' = ')
            strategy = parts[1]
            print("- found strategy '{}'".format(strategy))
            break
    # copy old ini file, but replace strategy block
    stratfield = '[' + strategy + ']'
    print("Writing temporary ini file (replacing section {})".format(stratfield))
    if verbose:
        print()
    insection = False
    for oneline in inilines:
        oneline = oneline.strip()
        if not insection:
            iniline_out.append(oneline)
            if verbose:
                print("- {}".format(iniline_out[-1]))
            if oneline.startswith('['):
                if oneline == stratfield:
                    print("- modifying section '{}' ...".format(oneline))
                    insection = True
                else:
                    print("- copying section '{}' ...".format(oneline))
                    insection = False
        else:
            if oneline.startswith('['):
                insection = False
                iniline_out.append(oneline)
            elif oneline.startswith('#') or (oneline == ''):
                # copy comments
                iniline_out.append(oneline)
                if verbose:
                    print("- {}".format(iniline_out[-1]))
            else:
                # replace field content
                parts = oneline.split(' = ')
                if parts[0] in ht_params:
                    iniline_out.append(parts[0] + ' = ' + ht_params[parts[0]])
                    if verbose:
                        print("x {}".format(iniline_out[-1]))
                else:
                    iniline_out.append(oneline)
                    if verbose:
                        print("- {}".format(iniline_out[-1]))
    # write new ini file
    myfile = open(outfile + '.ini', 'w', newline='')
    for oneline in iniline_out:
        myfile.write(oneline + '\n')
    myfile.close()

def bs_worker(outfile):
    print("\nStarting backtest with '{}' ...".format(outfile))
    sys.stdout.flush()
    if platform.system().lower() == 'windows':
        cmd_python = 'python'
    else:
        cmd_python = 'python3'
    outfile_ini = outfile + '.ini'
    args = [cmd_python, 'backtest.py', '-o', outfile, '-c', outfile_ini]
    tmpfile = outfile + '.tmp.log'
    output = open(tmpfile, 'w')
    subprocess.run(args, stdout=output, stderr=subprocess.STDOUT)
    output.close()
    #if os.path.exists(tmpfile):
    #    os.remove(tmpfile)
    print("Finished backtest.")
    sys.stdout.flush()


# =======================================================
#
# MAIN
#
# =======================================================


if __name__ == '__main__':

    if (len(sys.argv) == 1) or (sys.argv[1] == '-h'):
        print("\nUsage:\npython {0:s} -in <infile> -idx <idx> [-v]\n".format(sys.argv[0]))
        print("")
        print("Perform an Backtest for Parameter Set <idx> for LinRegBot {} ...".format(LRBotVersion))
        print("")
        print("")
        print("This scripts extracts the parameters of an given idx from a result csv file, ")
        print("creates a corresponding backtest.ini and startes a single backtest for it.")
        print("")
        print("")
        print("")
        print("\t-h:                print this help text")
        print("")
        print("")
        print("\t-in <infile>       csv file with parametersets")
        print("")
        print("")
        print("\t-idx <idx>:        the index with the <infile> you want to get")
        print("\t                   the detailed LOG and CSV for each test intervall")
        print("")
        print("\t-v:                verbose output")
        print("")
        print("")
        exit()

    argmode = 0
    no_idx = -1
    inifile = 'lrbacktest07.ini'
    verbose = False

    for onearg in sys.argv:
        if onearg == '-in':
            argmode = 1
        elif onearg == '-idx':
            argmode = 2
        elif onearg == '-v':
            verbose = True
        else:
            if argmode == 1:
                infile = onearg
                if not infile.endswith('.csv'):
                    print("\nSorry, only csv files are supported!")
                    print("(Your file: '{}')".format(infile))
                    exit()
            elif argmode == 2:
                no_idx = int(onearg)
                if (no_idx < 0) or (no_idx > 10000):
                    print("\nError - your index {} must be between 0 (incl) and 10000 (excl)".format(no_idx))
                    time.sleep(3)
                    exit()

    print("\nLooking for {} to extract parameter set of index {}.\n".format(infile, no_idx))

    if not os.path.exists(infile):
            print("\nError - your infile '{}' doesn't exist here.".format(infile))
            time.sleep(3)
            exit()

    # load infile with all parameter sets
    intable = bs_loadcsvfile(infile)
    ht_params = bs_getidx(no_idx, intable)
    if len(ht_params) == 0:
        print("Parameter Set {} not found.".format(no_idx))
        exit()

    inilines = bs_load_inifile(inifile)

    outfile = 'backtest_{0:04d}'.format(no_idx)
    bs_write_inifile(inilines, ht_params, outfile)

    bs_worker(outfile)
