import sys
import datetime

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.dates as mdates



if (len(sys.argv) < 2):
            print("\nWrong usage, please use 'show_ohcl.py <candlefile.csv>'")

else:


    filename = sys.argv[1] 

    data = np.genfromtxt(open(filename, "rb"), delimiter=",", skip_header=1, names=['timestamp', 'open', 'high', 'low', 'close', 'weightedAverage', 'volume', 'date'])

    x = data['timestamp']
    dates = mdates.epoch2num(x)
    y1 = data['open']
    y2 = data['high']
    y3 = data['low']
    y4 = data['close']

    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.set_ylabel('price', color='r')
    plt.plot(dates,y1, label='open')
    plt.plot(dates,y2, label='high')
    plt.plot(dates,y3, label='low')
    plt.plot(dates,y4, label='close')

    plt.legend(loc='upper left');

    # Choose your xtick format string
    date_fmt = '%d-%m-%y %H:%M:%S'
    # Use a DateFormatter to set the data to the correct format.
    date_formatter = mdates.DateFormatter(date_fmt)
    ax1.xaxis.set_major_formatter(date_formatter)
    # Sets the tick labels diagonal so they fit easier.
    fig.autofmt_xdate()


    plt.xlabel('Date')
    plt.title(filename)
    plt.grid(True)

    plt.show()

exit()
