import sys
import os
import platform
import shutil
import time
import csv

import multiprocessing
import subprocess


from lrhelper import LRBotVersion

# ==================================================

def tm_loadcsvfile(infile):
    csvFile = open(infile)
    csvReader = csv.reader(csvFile)
    csvlines = list(csvReader)
    csvFile.close()
    return csvlines

def tm_savecsvfile(outfile, title, csvlines):
    outputFile = open(outfile, 'w', newline='')
    outputWriter = csv.writer(outputFile)
    outputWriter.writerow(title)
    for oneline in csvlines:
        outputWriter.writerow(oneline)
    outputFile.close()

def tm_splitinputlines(csvlines_in, outfile, splitsize):
    title = csvlines_in[0]
    csvlines_in = csvlines_in[1:]
    cnt_all = len(csvlines_in)
    cnt_onefile = 0
    list_outfiles = []
    while cnt_all > splitsize:
        outfile_next = outfile + "_{0:04d}_a_in.csv".format(cnt_onefile)
        list_outfiles.append(outfile_next)
        print("- saving {} parameter sets in '{}' ...".format(splitsize, outfile_next))
        tm_savecsvfile(outfile_next, title, csvlines_in[0 : splitsize])
        csvlines_in = csvlines_in[splitsize : ]
        cnt_all -= splitsize
        cnt_onefile += 1
    if cnt_all > 0:
        outfile_next = outfile + "_{0:04d}_a_in.csv".format(cnt_onefile)
        list_outfiles.append(outfile_next)
        print("- saving {} parameter sets in '{}' ...".format(len(csvlines_in), outfile_next))
        tm_savecsvfile(outfile_next, title, csvlines_in)
    return list_outfiles

# ==================================================

def  tm_add_to_outtable(title, outfile_old, outfile_new, list_outfiles):
    table_end = []
    sys.stdout.flush()
    for onefile in list_outfiles:
        newfile = onefile.replace('_a_in.csv', '_end_out.csv')
        if not os.path.exists(newfile):
            continue
        print("  - including data from {}".format(newfile))
        newlines = tm_loadcsvfile(newfile)
        table_end += newlines[1:]
    print("saving {} combined results in file '{}' ...".format(len(table_end), outfile_new))
    sys.stdout.flush()
    tm_savecsvfile(outfile_new, title, table_end)

def tm_worker(th_args):
    (title, outfile, list_outfiles) = th_args
    outfile_new = outfile.replace('_a_in.csv', '_end_out.csv')
    #print(outfile, outfile_new)
    if os.path.exists(outfile_new):
        print("- skipping already computed backtest with result '{}' ...".format(outfile_new))
        sys.stdout.flush()
    else:
        print("- starting backtest with '{}' ...".format(outfile))
        sys.stdout.flush()
        if platform.system().lower() == 'windows':
            cmd_python = 'python'
        else:
            cmd_python = 'python3'
        if '0000_a_in.csv' in outfile:
            args = [cmd_python, 'backtest.py', '-w', '-nof', '-r', outfile]
        else:
            args = [cmd_python, 'backtest.py', '-nof', '-r', outfile]
        tmpfile = outfile.replace('_a_in.csv', '.tmp.log')
        output = open(tmpfile, 'w')
        subprocess.run(args, stdout=output, stderr=subprocess.STDOUT)
        output.close()
        #if os.path.exists(tmpfile):
        #    os.remove(tmpfile)
        print("- finished backtest with '{}' ...".format(outfile))
        sys.stdout.flush()
        outfile_old = outfile.replace('_a_in.csv', '_end_out.csv')
        outfile_new = outfile.replace('_a_in.csv', '_tmp_end_out.csv')
        tm_add_to_outtable(title, outfile_old, outfile_new, list_outfiles)


def tm_downloader(outfile):
    print("- starting candle data download ...")
    sys.stdout.flush()
    if platform.system().lower() == 'windows':
        cmd_python = 'python'
    else:
        cmd_python = 'python3'
    args = [cmd_python, 'backtest.py', '-dlo']
    tmpfile = outfile + '.tmp.log'
    output = open(tmpfile, 'w')
    subprocess.run(args, stdout=output, stderr=subprocess.STDOUT)
    output.close()
    if os.path.exists(tmpfile):
        os.remove(tmpfile)
    print("- finished candle data download\n")
    sys.stdout.flush()


# =======================================================
#
# MAIN
#
# =======================================================


if __name__ == '__main__':

    if (len(sys.argv) == 1) or (sys.argv[1] == '-h'):
        print("\nUsage:\npython {0:s} -r <inputfile> [-s <splitsize>] [-t <threads>]\n".format(sys.argv[0]))
        print("")
        print("Backtest Manager for LinRegBot {} ...".format(LRBotVersion))
        print("")
        print("")
        print("This backtest Manager gets the an input csv file parameter file and tests")
        print("these parameter sets with <threads> parallel backtests.")
        print("")
        print("Each backtest gets <splitsize> parameter sets to test. If it's finished,")
        print("it's restarted with the next <splitsize> parameter sets")
        print("")
        print("")
        print("\t-h:                print this help text")
        print("")
        print("")
        print("\t-r <inputfile>     start backtest with input file <inputfile>")
        print("")
        print("")
        print("\t-s <size>:         split parameter input file in many smaller files")
        print("\t                   with <size> combinations each file")
        print("\t                   (Default is -s 50)")
        print("")
        print("\t-t <threads>:      start <threads> parallel backtests")
        print("\t                   (Default is -t 2)")
        print("")
        exit()

    argmode = 0
    no_split = 50
    no_threads = 2
    outfile = '--- nothing given ---'

    for onearg in sys.argv:
        if onearg == '-r':
            argmode = 1
        elif onearg == '-s':
            argmode = 2
        elif onearg == '-t':
            argmode = 3
        else:
            if argmode == 1:
                infile = onearg
                paramsfile_out = onearg
                if paramsfile_out.endswith('_a_in.csv'):
                    outfile = paramsfile_out.replace('_a_in.csv', '')
                else:
                    print("\nSorry, only files ending with 'a_in.csv' are supported!")
                    exit()
            elif argmode == 2:
                no_split = int(onearg)
                if (no_split < 5) or (no_split > 10000):
                    print("\nError - your splitsize {} must be between 5 and 10000".format(no_split))
                    time.sleep(3)
                    exit()
            elif argmode == 3:
                no_threads = int(onearg)
                if (no_threads < 1) or (no_threads > 64):
                    print("\nError - your threads number {} must be between 1 and 64".format(no_threads))
                    time.sleep(3)
                    exit()

    print("\nStarting {} parallel backtests with {} parameter sets each\nfrom input file '{}'.\n".format(no_threads, no_split, infile))

    if not os.path.exists(infile):
            print("\nError - your infile '{}' doesn't exist here.".format(infile))
            time.sleep(3)
            exit()

    # load infile with all parameter sets
    intable = tm_loadcsvfile(infile)
    title = intable[0]
    print("Infile '{}' contains {} parameter sets.\n".format(infile, len(intable)-1))
    # and split it into pieces with size <no_split>
    list_outfiles = tm_splitinputlines(intable, outfile, no_split)
    print("")

    # first download all the candles (if neccessary)
    tm_downloader(outfile)

    # create the argument list for the threads
    list_args = [(title, one_outfile, list_outfiles) for one_outfile in list_outfiles]
    # now start <no_threads> backtests
    p = multiprocessing.Pool(no_threads)
    p.map(tm_worker, list_args)

    print("all backtests finished ...")
    sys.stdout.flush()
    table_end = []
    for onefile in list_outfiles:
        newfile = onefile.replace('_a_in.csv', '_end_out.csv')
        if not os.path.exists(newfile):
            continue
        newlines = tm_loadcsvfile(newfile)
        table_end += newlines[1:]
    print("Saving final {} combined results in file '{}' ...".format(len(table_end), outfile + '_end_all_out.csv'))
    tm_savecsvfile(outfile + '_end_all_out.csv', title, table_end)
    exit()
