import sys
import datetime

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.dates as mdates



if (len(sys.argv) < 2):
            print("\nWrong usage, please use 'show_bt.py <testfile.bt.csv'")

else:


    filename = sys.argv[1]

    data = np.genfromtxt(open(filename, "rb"), delimiter=",", skip_header=1, names=['time', 'date', 'equity', 'balance', 'coins', 'range', 'buyandhold'])

    x = data['time']
    dates = mdates.epoch2num(x)
    y1 = data['equity']
    y2 = data['balance']
    y20 = data['coins']
    y21 = data['buyandhold']

    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.set_ylabel('equity', color='r')
    plt.plot(dates,y1, label='equity')
    plt.plot(dates,y2, label='balance')
    plt.plot(dates,y21, label='buyandhold')

    plt.legend(loc='upper left');
    """
    ax2 = ax1.twinx()
    ax2.plot(dates, y20, label='coins', color='y')
    ax2.set_ylabel('coins', color='b')
    """
    # Choose your xtick format string
    date_fmt = '%d-%m-%y %H:%M:%S'
    # Use a DateFormatter to set the data to the correct format.
    date_formatter = mdates.DateFormatter(date_fmt)
    ax1.xaxis.set_major_formatter(date_formatter)
    # Sets the tick labels diagonal so they fit easier.
    fig.autofmt_xdate()


    plt.xlabel('Date')
    plt.title(filename)
    plt.grid(True)

    plt.show()

exit()
