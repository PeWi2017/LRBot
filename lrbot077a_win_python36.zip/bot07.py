from lrbot07 import main      # this comes from a compiled binary
main (None)
