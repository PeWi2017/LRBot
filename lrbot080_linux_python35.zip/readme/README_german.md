# LinRegBot
Der LinRegBot (kurz LRBot) ist ein Tradingbot für Binance und Poloniex.
Weitere Börsen sind geplant.

### Strategie
Im Gegensatz zu den meisten Bots verfolgt er einen eigenen Ansatz. Dadurch, dass die Tradingmethodik in Modulen gekapselt ist, kann man die komplette Tradingstrategie wechseln.

Derzeit gibt es zwei Module; beiden ist gemein, dass der Bot in Bärenmärkten die Coins in Stable-Coins (USDT) tauscht und so die Balance erhält. Normale Bots bleiben üblicherweise in den Coins und haben so 2018 herbe Verluste eingefahren. Weitere Strategiemodule sind in Entwicklung.

Alle bisherigen Module verkaufen fallende Coins zeitig, deshalb gibt es keine Bags und es wird kein DCA benötigt, welches zwar kleinere Probleme löst, aber im Gegenzug größere Bags schafft.

### Backtest
Es wird ein Backtest-Modul mitgeliefert, siehe entsprechende Dokumentation.

### Lizenz
Seit Version 0.7.1 wird zum Betrieb eine Lizenz benötigt, siehe entsprechende Dokumentation.
Bei Interesse bin ich via Telegram (@pewi2017) oder Email (autopt_binance@gmx.net) zu erreichen.

## Voraussetzungen und Installation
### Voraussetzungen
Windows:  
Python 64bit Version 3.6.x  
Linux:  
Python 64bit Version 3.5.x bzw. 3.6.x
  
Achtung:  
Unter Ubuntu 18.04 und höher gibt es ein Problem mit Python 3.6, welches zu einer Fehlermeldung beim Start ("undefined symbol: PyFPE_jbuf") und Programmabbruch führt. Abhilfe: Manuell Python 3.5 nachinstallieren und die Archive für Python 3.5.x des LRBots verwenden.

### Installation
Windows:  
- Python 3.6 (64 Bit) installieren  
- LRBot-Zip-Archiv in ein neues Verzeichnis auspacken  
- Konsolenfenster öffnen und zum Verzeichnis wechseln  
- ```lrinstall1.cmd```  
- ```lrinstall2.cmd```  
- Lizenzdatei lrbot.lic ins Verzeichnis kopieren  

Linux:  
- Python 3.5 bzw. 3.6 (64 Bit) installieren  
- passendes LRBot-Zip-Archiv in ein neues Verzeichnis auspacken  
- Konsolenfenster öffnen und zum Verzeichnis wechseln  
- ```python3 -m venv .env```  
- ```source .env/bin/activate```  
- ```./lrinstall2.sh```  
- Lizenzdatei lrbot.lic ins Verzeichnis kopieren  

(Exkurs zum Verständnis des virtuellen Environment siehe unten)

Einstellungen in den Configs anpassen:  
- lrbot.secrets.ini anpassen  
  (API-Key und -Secret, Telegram-Kennungen, ggfs Account-Passwort bei cryptocompare.com)  
- lrbot.ini  
  Default ist Papertrading mit der Strategie 'ma3'

**Achtung:**
Wenn man den Bot später zum Geldverdienen einsetzen will, dann sollte man die geplanten Einstellungen der gewählten Strategie zuvor ausführlichen Tests unterziehen. Mehr dazu in der Dokumentation zum mitgelieferten Backtest-Modul. Ebenso finden sich dort Beschreibungen zu allen Parametern der Config-Datei.


## LRBot starten
Windows:  
```lrbot.cmd```  
Linux:  
```./lrbot.sh```

Wer einen andere als die standardmäßig verwendete Config-Datei lrbot.ini verwenden möchte, kann dies mit dem Parameter '-c <configfile>' tun.

Der Bot gibt auf der Konsole und per Telegram Statusmeldungen aus:  
- beim Hochfahren
- nach jeder neuen Kerze (Balance und Stand an Coins)
- jeder Kauf und jeder Verkauf
- optional zu jeder vollen Candle Info-Meldungen

Sämtliche Meldungen bis auf Kauf/Verkauf lassen sich in der Config auch stummschalten.

Man kann den Bot jederzeit mit STRG-C abbrechen und neu starten, da der Bot anhand der Informationen von der Börse alle Laufzeitdaten wieder richtig erstellt. Manche Operationen (z.B. Holen von Candles, Kauf/Verkauf) lassen sich nicht sofort abbrechen, der Bot führt die Operation bis zum Ende aus und beendet sich dann.


## EXKURS
Nur zum besseren Verständnis ;-)

Unter Python kann man virtuelle Umgebungen schaffen. Das hat den Vorteil, dass man verschiedene Python-Programme, die alle möglicherweise ganz verschiedene Module importieren möchten, laufen lassen kann, ohne dass sie sich beeinflussen können, weil jedes damit seine eigene Umgebung und nur seine eigenen Module hat. Jede virtuelle Python-Umgebung fängt erst mal neu an. Jedes benötigte Modul muss in der virtuellen Umgebung einmalig neu installiert werden.

In der virtuellen Umgebung ist unter Linux beim Installieren von Modulen übrigens kein sudo notwendig, weil die Umgebung nur im Kontext des angemeldeten Benutzers erstellt wird.

Der LRBot arbeitet in einer solchen virtuellen Python-Umgebung, die durch die Installation angelegt wird. Dazu einige Erklärungen und Hinweise, was die Installation tut.

### Virtuelle Umgebung beim ersten Mal erzeugen
- ins gewünschte Verzeichnis wechseln, in dem die Python-Dateien liegen
- Virtuelle Umgebung erzeugen  
Windows:  
```python -m venv .env```  
Linux:  
```python3 -m venv .env```

Ggfs muss unter Linux zuvor das Paket für virtuellen Umgebungen noch installiert werden:  
```sudo pip3 install virtualenv```

Die virtuelle Python-Umgebung wird erzeugt, Unterverzeichnis .env mit notwendigen Dateien wird im aktuellen Verzeichnis erstellt.

### Virtuelle Umgebung aktivieren für Installation und Start des LRBot
Windows:  
```.env\Scripts\activate.bat```  
Linux:  
```source .env/bin/activate```  

Der angezeigte Prompt ändert sich; daran sieht man, dass das Environment aktiviert ist.
Oft bekommt man dabei unter Windows eine Fehlermeldung über eine falsche Codepage. Das bezieht sich aber nur darauf, dass die Codepage von Windows aus Sicht des Environments "falsch" ist und kann also getrost ignoriert werden.

Falls man die virtuelle Umgebung wieder verlassen möchte:  
Windows:  
```.env\Scripts\deactivate.bat```  
Linux:  
```deactivate```

### Notwendige Python-Module in virtuelle Umgebung installieren
- Ggfs pip updaten  
Windows:  
```python -m pip install --upgrade pip```  
Linux:  
```python3 -m pip3 install --upgrade pip```  
- Module installieren  
Windows:  
```pip install -r requirements.txt```  
Linux:  
```pip3 install -r requirements.txt```  

ENDE EXKURS
