#!/bin/bash

source .env/bin/activate

while true
	do
	python3 -u bot.py  2>&1 | tee -a lrconsole.log

	if [ "$?" -eq "0" ]; then
		echo "Properly shut down. Thanks for all the fish."
		break
	fi

	if [ "$?" -eq "99" ]; then
		echo "Reboot requested. Let's start over..."
		sleep 1
	else
		echo "Some kind of error occured. Cooling down a bit and trying again..."
		sleep 60
	fi
done
